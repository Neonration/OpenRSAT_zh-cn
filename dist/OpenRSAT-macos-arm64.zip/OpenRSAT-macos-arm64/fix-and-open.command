#!/bin/zsh
set -e

SCRIPT_DIR="${0:A:h}"
APP_PATH="$SCRIPT_DIR/OpenRSAT.app"

if [[ ! -d "$APP_PATH" ]]; then
  echo "OpenRSAT.app was not found. Put this script next to OpenRSAT.app and run it again."
  read -k 1 "?Press any key to exit..."
  exit 1
fi

echo "Removing macOS quarantine attributes..."
/usr/bin/xattr -dr com.apple.quarantine "$APP_PATH" 2>/dev/null || true

echo "Applying local ad-hoc signature..."
/usr/bin/codesign --force --deep --sign - "$APP_PATH"

echo "Verifying signature..."
/usr/bin/codesign --verify --deep --verbose=2 "$APP_PATH"

echo ""
echo "Done. Opening OpenRSAT..."
/usr/bin/open "$APP_PATH"

echo ""
echo "If macOS still blocks the app, open System Settings > Privacy & Security and allow OpenRSAT."
read -k 1 "?Press any key to close..."
